<?php
/**
 * Created by PhpStorm.
 * User: mickey
 * Date: 2018/7/28
 * Time: 13:55
 */

return [
    'http_proxy' => '127.0.0.1:1087',
    'weiboCookie' => 'SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WW3PsCb55p3CXxHR9oDv0OW5JpX5KzhUgL.FozN1KefehzXS052dJLoIEXLxKBLB.BLBK5LxKnL1hBLBo2LxKnLBoBLB-zLxKBLB.2L1hqLxK-L1K5L1KMt;  SUB=_2A25xqLwdDeRhGeRJ4lEU8CzIzDyIHXVS36rVrDV8PUNbn9BeLWTXkW9NUklEG2ghQmTSYlBq7Ojj_RI2o5TCBO6W;',

    'user_agent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',

    //91porn
    '91porn' => [
        'cookie' => '__cfduid=d0c8526622bb38b0743a82ba8b6357b921565693139; cf_clearance=f3d7f651faea2f13421576bbda6b915e46faeac7-1565693150-604800-250; __utma=50351329.352813094.1565693152.1565693152.1565693152.1; __utmb=50351329.0.10.1565693152; __utmc=50351329; __utmz=50351329.1565693152.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); CLIPSHARE=aq5qjtf66pi06i5fgacm1rlrq4; __51cke__=; __dtsu=1EE70445EE94525DB545BE0E02F9ACBC; watch_times=1; __tins__3878067=%7B%22sid%22%3A%201565693159696%2C%20%22vd%22%3A%203%2C%20%22expires%22%3A%201565694980498%7D; __51laig__=3',
        'user_agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36',
    ],

    //webui-aria2
    'aria2' => [
        'jsonrpc_path' => 'http://localhost:6800/jsonrpc',
        'token' => 'bb413b88-6f0e-4c51-98aa-a5662849aa69',
    ],
];